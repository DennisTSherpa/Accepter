#!/bin/sh
# Author: Amittai Aviram - aviram@bc.edu

# Variable definitions
PROG=accepter
HW=pa1
INPUT=input_${HW}
OUTPUT=output.txt
EXPECTED=expected_${HW}.txt

# Remove any remaining artifacts from a previous test run.
rm -f ${PROG}
rm -f ${OUTPUT}

# Build the executable with all warnings and with warnings treated as errors.
g++ -Wall -Werror -std=c++17 ${PROG}.cpp -o ${PROG}

# Run the program with a valid argument.
# Redirect output to the output file by appending.
for i in {1..4}
do
    ./${PROG} < ${INPUT}_$i.txt >> ${OUTPUT} 2>&1
    # ./${PROG} < ${INPUT}_$i.txt
done

# Test whether the aggregate actual output file matches the
# expected output file.
if diff -q --strip-trailing-cr ${OUTPUT} ${EXPECTED} &> /dev/null
then
    echo "PASSED"
else
    echo "FAILED"
fi

# Clean up.
rm -f ${PROG}
rm -f ${OUTPUT}

